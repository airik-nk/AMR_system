automod::dir!("tests/regression");
