This is serde-json with perfect_float.patch applied.
